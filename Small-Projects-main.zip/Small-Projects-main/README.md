# Small Projects
Here you can find some of my smaller projects. Most of them are Arduino based, there are also schematics and PCB design files. Feel free to fork and make it even better! Don't forget to share with others and with me, I would love to see how you adapt those small projects into something bigger :)

[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/tjKySKeDoCE/0.jpg)](https://www.youtube.com/watch?v=tjKySKeDoCE)
[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/q_4-i3iNggE/0.jpg)](https://www.youtube.com/watch?v=q_4-i3iNggE)
[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/zZ40o9QnoUY/0.jpg)](https://www.youtube.com/watch?v=zZ40o9QnoUY)
