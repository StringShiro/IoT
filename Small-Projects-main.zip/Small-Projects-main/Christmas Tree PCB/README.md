# Christmas-Tree-PCB
Last Christmas I made 3D printed cookie cutters and this Christmas I wanted to make a cool electronics project. I designed a Christmas tree PCB in kicad and then ordered it online at jlcpcb.com. Few LEDs, 2 10 Ohm resistors, battery box and you have a great Christmas ornament or gift :)

https://www.youtube.com/watch?v=JdUFrBdkSZM
