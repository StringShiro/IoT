# EncoderMotorDriver

Simple project of Arduino based encoder driver that communicates over I2C to make it easy to use motors with encoders in any Arduino based project. You can find here a source code and design files for the PCB, for more info check out my YouTube video:
<br/>
[![](http://img.youtube.com/vi/zZ40o9QnoUY/0.jpg)](http://www.youtube.com/watch?v=zZ40o9QnoUY "")
 